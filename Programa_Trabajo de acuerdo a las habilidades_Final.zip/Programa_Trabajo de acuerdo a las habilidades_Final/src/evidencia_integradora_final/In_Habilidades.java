package evidencia_integradora_final;

public class In_Habilidades extends javax.swing.JFrame {
public In_Habilidades() {
        initComponents();
    }




 public static String [] intercambio = new String [9];

    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        buttonGroup4 = new javax.swing.ButtonGroup();
        buttonGroup5 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        sig1 = new javax.swing.JButton();
        h1 = new javax.swing.JRadioButton();
        h5 = new javax.swing.JRadioButton();
        h8 = new javax.swing.JRadioButton();
        h6 = new javax.swing.JRadioButton();
        h10 = new javax.swing.JRadioButton();
        h4 = new javax.swing.JRadioButton();
        h7 = new javax.swing.JRadioButton();
        h2 = new javax.swing.JRadioButton();
        h3 = new javax.swing.JRadioButton();
        h9 = new javax.swing.JRadioButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        vol2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Swis721 Blk BT", 2, 18)); // NOI18N
        jLabel1.setText("Selecciona 5 habilidades que poseas actualmente");

        sig1.setText("Siguiente");
        sig1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sig1ActionPerformed(evt);
            }
        });

        buttonGroup1.add(h1);
        h1.setText("Escritura y Edicion");
        h1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                h1ActionPerformed(evt);
            }
        });

        buttonGroup3.add(h5);
        h5.setText("Diseño Grafico");

        buttonGroup4.add(h8);
        h8.setText("Servicios en la nube");

        buttonGroup3.add(h6);
        h6.setText("Lenguaje de Programacion");
        h6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                h6ActionPerformed(evt);
            }
        });

        buttonGroup5.add(h10);
        h10.setText("Emision de Informes de Gastos");

        buttonGroup2.add(h4);
        h4.setText("Contabilidad");

        buttonGroup4.add(h7);
        h7.setText("Gestion de la Informacion");

        buttonGroup1.add(h2);
        h2.setText("Seguridad de redes");

        buttonGroup2.add(h3);
        h3.setText("Dominio de mas de un idioma");

        buttonGroup5.add(h9);
        h9.setText("Gestion de proyectos");

        jLabel2.setFont(new java.awt.Font("Trebuchet MS", 2, 14)); // NOI18N
        jLabel2.setText("Opcion 1");

        jLabel3.setFont(new java.awt.Font("Trebuchet MS", 2, 14)); // NOI18N
        jLabel3.setText("Opcion 2");

        jLabel4.setFont(new java.awt.Font("Trebuchet MS", 2, 14)); // NOI18N
        jLabel4.setText("Opcion 4");

        jLabel5.setFont(new java.awt.Font("Trebuchet MS", 2, 14)); // NOI18N
        jLabel5.setText("Opcion 3");

        jLabel6.setFont(new java.awt.Font("Trebuchet MS", 2, 14)); // NOI18N
        jLabel6.setText("Opcion 5");

        vol2.setText("VOLVER");
        vol2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vol2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addComponent(jLabel6)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(h10, javax.swing.GroupLayout.DEFAULT_SIZE, 286, Short.MAX_VALUE)
                            .addComponent(h9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(h6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(sig1)
                        .addGap(46, 46, 46))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel5)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(h2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 306, Short.MAX_VALUE)
                                .addComponent(h1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(h5, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(122, 122, 122)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel3)))
                            .addComponent(h8, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(h3, javax.swing.GroupLayout.DEFAULT_SIZE, 281, Short.MAX_VALUE)
                                .addComponent(h7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(h4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(vol2)
                        .addGap(72, 72, 72)
                        .addComponent(jLabel1)
                        .addGap(206, 206, 206))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(vol2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel1)))
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(h3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(h4))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(h1)
                        .addGap(18, 18, 18)
                        .addComponent(h2)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(h7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(h5)
                        .addGap(4, 4, 4)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(h6)
                    .addComponent(h8))
                .addGap(50, 50, 50)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(h9)
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(sig1)
                    .addComponent(h10))
                .addGap(15, 15, 15))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

  
    private void sig1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sig1ActionPerformed
        In_Educativa llamar1=new In_Educativa();
       llamar1.setVisible(true);
       
      
     
       
       Condiciones();
       
       
       this.dispose();
       
    }//GEN-LAST:event_sig1ActionPerformed

    private void h6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_h6ActionPerformed
       
    }//GEN-LAST:event_h6ActionPerformed

    private void h1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_h1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_h1ActionPerformed

    private void vol2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vol2ActionPerformed
        Principal an2= new Principal();
        an2.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_vol2ActionPerformed

    
public String[] Condiciones(){
    Evidencia_Integradora_Final x = new Evidencia_Integradora_Final();
     if(h1.isSelected() && h3.isSelected()){
        x.colocar_datos(x.oferta[17],intercambio);
       
    }if(h1.isSelected() && h4.isSelected()){
        x.colocar_datos(x.oferta[5],intercambio);
        
    }
    if(h1.isSelected() && h5.isSelected()){
        x.colocar_datos(x.oferta[0],intercambio);
       
    }
    if(h1.isSelected() && h6.isSelected()){
        x.colocar_datos(x.oferta[27],intercambio);
        
    }
    if(h1.isSelected() && h7.isSelected()){
        x.colocar_datos(x.oferta[10],intercambio);
        
    }
    if(h1.isSelected() && h8.isSelected()){
        x.colocar_datos(x.oferta[16],intercambio);
        
    }
    if(h1.isSelected() && h9.isSelected()){
        x.colocar_datos(x.oferta[7],intercambio);
      
    }
    if(h1.isSelected() && h10.isSelected()){
        x.colocar_datos(x.oferta[2],intercambio);
       
    }
    
    if(h2.isSelected() && h3.isSelected()){
        x.colocar_datos(x.oferta[10],intercambio);
       
    }if(h2.isSelected() && h4.isSelected()){
        x.colocar_datos(x.oferta[21],intercambio);
       
    }
    if(h2.isSelected() && h5.isSelected()){
        x.colocar_datos(x.oferta[23],intercambio);
       
    }
    if(h2.isSelected() && h6.isSelected()){
        x.colocar_datos(x.oferta[31],intercambio);
       
    }
    if(h2.isSelected() && h7.isSelected()){
        x.colocar_datos(x.oferta[36],intercambio);
        
    }
    if(h2.isSelected() && h8.isSelected()){
        x.colocar_datos(x.oferta[6],intercambio);
        
    }
    if(h2.isSelected() && h9.isSelected()){
        x.colocar_datos(x.oferta[25],intercambio);
      
    }
    if(h2.isSelected() && h10.isSelected()){
        x.colocar_datos(x.oferta[19],intercambio);
        
    }

    if(h3.isSelected() && h5.isSelected()){
        x.colocar_datos(x.oferta[4],intercambio);
       
    }if(h3.isSelected() && h6.isSelected()){
        x.colocar_datos(x.oferta[20],intercambio);
       
    }
    if(h3.isSelected() && h7.isSelected()){
        x.colocar_datos(x.oferta[8],intercambio);
      
    }
    if(h3.isSelected() && h8.isSelected()){
        x.colocar_datos(x.oferta[1],intercambio);
     
    }
    if(h3.isSelected() && h9.isSelected()){
        x.colocar_datos(x.oferta[11],intercambio);
       
    }
    if(h3.isSelected() && h10.isSelected()){
        x.colocar_datos(x.oferta[24],intercambio);
        
    }

    if(h4.isSelected() && h5.isSelected()){
        x.colocar_datos(x.oferta[9],intercambio);
       
    }if(h4.isSelected() && h6.isSelected()){
        x.colocar_datos(x.oferta[33],intercambio);
       
    }
    if(h4.isSelected() && h7.isSelected()){
        x.colocar_datos(x.oferta[12],intercambio);
      
    }
    if(h4.isSelected() && h8.isSelected()){
        x.colocar_datos(x.oferta[20],intercambio);
        
    }
    if(h4.isSelected() && h9.isSelected()){
        x.colocar_datos(x.oferta[38],intercambio);
       
    }
    if(h4.isSelected() && h10.isSelected()){
        x.colocar_datos(x.oferta[2],intercambio);
       
    }

    if(h5.isSelected() && h7.isSelected()){
        x.colocar_datos(x.oferta[5],intercambio);
       
    }
    if(h5.isSelected() && h8.isSelected()){
        x.colocar_datos(x.oferta[15],intercambio);
       
    }
    if(h5.isSelected() && h9.isSelected()){
        x.colocar_datos(x.oferta[13],intercambio);
      
    }
    if(h5.isSelected() && h10.isSelected()){
        x.colocar_datos(x.oferta[18],intercambio);
       
    }

    if(h6.isSelected() && h7.isSelected()){
        x.colocar_datos(x.oferta[33],intercambio);
       
    }
    if(h6.isSelected() && h8.isSelected()){
        x.colocar_datos(x.oferta[3],intercambio);
     
    }
    if(h6.isSelected() && h9.isSelected()){
        x.colocar_datos(x.oferta[26],intercambio);
        
    }
    if(h6.isSelected() && h10.isSelected()){
        x.colocar_datos(x.oferta[37],intercambio);
       
    }
    
    if(h7.isSelected() && h9.isSelected()){
        x.colocar_datos(x.oferta[35],intercambio);
        
    }
    if(h7.isSelected() && h10.isSelected()){
        x.colocar_datos(x.oferta[22],intercambio);
       
    }
    if(h8.isSelected() && h9.isSelected()){
        x.colocar_datos(x.oferta[3],intercambio);
     
    }
    if(h8.isSelected() && h10.isSelected()){
        x.colocar_datos(x.oferta[29],intercambio);
       
    }

 
    return intercambio;

}

    public static void setIntercambio(String[] intercambio) {
        In_Habilidades.intercambio = intercambio;
    }
   
     
    
    
    

    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new In_Habilidades().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.ButtonGroup buttonGroup4;
    private javax.swing.ButtonGroup buttonGroup5;
    private javax.swing.JRadioButton h1;
    private javax.swing.JRadioButton h10;
    private javax.swing.JRadioButton h2;
    private javax.swing.JRadioButton h3;
    private javax.swing.JRadioButton h4;
    private javax.swing.JRadioButton h5;
    private javax.swing.JRadioButton h6;
    private javax.swing.JRadioButton h7;
    private javax.swing.JRadioButton h8;
    private javax.swing.JRadioButton h9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    public javax.swing.JButton sig1;
    private javax.swing.JButton vol2;
    // End of variables declaration//GEN-END:variables
}
