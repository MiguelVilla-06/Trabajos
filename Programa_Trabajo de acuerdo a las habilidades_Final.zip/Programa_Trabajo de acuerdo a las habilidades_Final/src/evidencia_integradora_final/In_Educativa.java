package evidencia_integradora_final;
public class In_Educativa extends javax.swing.JFrame {
public In_Educativa() {initComponents();}


    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        ed1 = new javax.swing.JRadioButton();
        ed2 = new javax.swing.JRadioButton();
        ed3 = new javax.swing.JRadioButton();
        ed4 = new javax.swing.JRadioButton();
        ed5 = new javax.swing.JRadioButton();
        ed6 = new javax.swing.JRadioButton();
        ed7 = new javax.swing.JRadioButton();
        ed8 = new javax.swing.JRadioButton();
        ed9 = new javax.swing.JRadioButton();
        sig2 = new javax.swing.JButton();
        op = new javax.swing.JButton();
        vol3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText("De acuerdo a tus habilidades, estas son las mejores opciones educativas para ti, elige una de ellas:");

        buttonGroup1.add(ed1);

        buttonGroup1.add(ed2);

        buttonGroup1.add(ed3);

        buttonGroup1.add(ed4);

        buttonGroup1.add(ed5);

        buttonGroup1.add(ed6);

        buttonGroup1.add(ed7);

        buttonGroup1.add(ed8);

        buttonGroup1.add(ed9);

        sig2.setText("Siguiente");
        sig2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sig2ActionPerformed(evt);
            }
        });

        op.setText("Mostrar opciones");
        op.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opActionPerformed(evt);
            }
        });

        vol3.setText("VOLVER");
        vol3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                vol3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(ed5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 276, Short.MAX_VALUE)
                            .addComponent(ed3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ed2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ed1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ed4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(46, 46, 46)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ed6, javax.swing.GroupLayout.DEFAULT_SIZE, 208, Short.MAX_VALUE)
                            .addComponent(ed7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ed8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(ed9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(75, 75, 75))
            .addGroup(layout.createSequentialGroup()
                .addGap(144, 144, 144)
                .addComponent(vol3)
                .addGap(52, 52, 52)
                .addComponent(op)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(sig2)
                .addGap(54, 54, 54))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(ed6)
                    .addComponent(ed1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(ed2)
                        .addGap(18, 18, 18)
                        .addComponent(ed3)
                        .addGap(18, 18, 18)
                        .addComponent(ed4))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(ed7)
                        .addGap(18, 18, 18)
                        .addComponent(ed8)
                        .addGap(18, 18, 18)
                        .addComponent(ed9)))
                .addGap(21, 21, 21)
                .addComponent(ed5)
                .addGap(50, 50, 50)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(vol3)
                    .addComponent(op)
                    .addComponent(sig2))
                .addContainerGap(9, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    
    
    
    
    
    
    
    
    
    private void sig2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sig2ActionPerformed
        In_Empleos llamar1=new In_Empleos();
        llamar1.setVisible(true);
           
            
          seleccion();
          this.dispose();
    }//GEN-LAST:event_sig2ActionPerformed

    private void opActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opActionPerformed
        
        In_Habilidades l = new In_Habilidades();
           l.Condiciones();
           
        ed1.setText(l.intercambio[0]);
        ed2.setText(l.intercambio[1]);
        ed3.setText(l.intercambio[2]);
        ed4.setText(l.intercambio[3]);
        ed5.setText(l.intercambio[4]);
        ed6.setText(l.intercambio[5]);
        ed7.setText(l.intercambio[6]);
        ed8.setText(l.intercambio[7]);
        ed9.setText(l.intercambio[8]);
    }//GEN-LAST:event_opActionPerformed

    private void vol3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_vol3ActionPerformed
        In_Habilidades an3 = new In_Habilidades();
        an3.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_vol3ActionPerformed

    
    public static String aplicar[]= new String [3];
    
    
    public void seleccion(){
         int  valor=0;
         Evidencia_Integradora_Final ven = new Evidencia_Integradora_Final();
          In_Habilidades l = new In_Habilidades();
      if(ed1.isSelected()){
          
          ven.aplicacion(aplicar, valor);
      }if(ed2.isSelected()){
          valor=1;
           ven.aplicacion(aplicar, valor);
          
      }if(ed3.isSelected()){
          valor=2;
           ven.aplicacion(aplicar, valor);
      }if(ed4.isSelected()){
          valor=3;
           ven.aplicacion(aplicar, valor);
      }if(ed5.isSelected()){
          valor=4;
           ven.aplicacion(aplicar, valor);
      }if(ed6.isSelected()){
          valor=5;
           ven.aplicacion(aplicar, valor);
      }if(ed7.isSelected()){
          valor=6;
           ven.aplicacion(aplicar, valor);
      }if(ed8.isSelected()){
          valor=7;
           ven.aplicacion(aplicar, valor);
      }if(ed9.isSelected()){
          valor=8;
           ven.aplicacion(aplicar, valor);
      }
        System.out.println(aplicar[0]);
        System.out.println(aplicar[1]);
        System.out.println(aplicar[2]);
    }

    public static void setAplicar(String[] aplicar) {
        In_Educativa.aplicar = aplicar;
    }
    
   
    
    public static void main(String args[]) {
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(In_Educativa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(In_Educativa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(In_Educativa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(In_Educativa.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
       

        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new In_Educativa().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JRadioButton ed1;
    private javax.swing.JRadioButton ed2;
    private javax.swing.JRadioButton ed3;
    private javax.swing.JRadioButton ed4;
    private javax.swing.JRadioButton ed5;
    private javax.swing.JRadioButton ed6;
    private javax.swing.JRadioButton ed7;
    private javax.swing.JRadioButton ed8;
    private javax.swing.JRadioButton ed9;
    private javax.swing.JLabel jLabel1;
    public javax.swing.JButton op;
    public javax.swing.JButton sig2;
    private javax.swing.JButton vol3;
    // End of variables declaration//GEN-END:variables
}
