package evidencia_integradora_final;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;


public class Evidencia_Integradora_Final {
     In_Habilidades enviar =new In_Habilidades();
boolean activado;





String[] oferta={"Marketing y Diseño","Desarrollador de software","Economista","Ingeniería en Inteligencia Artificial","Redactor Técnico",
    "Periodista","Programador","Editor de Libros/Periodicos",
    "Administracion de Empresas","Publirelacionista", "Crackeador/Reparador de software","Maestro de Idiomas","Licenciado en Informatica","Animador 3D/4D",
    "Director Ejecutivo","Diseñador de Paginas web",
    "Ingeniero en Comunicacion","Traductor de Libros/Programas","Licenciado en Relaciones Internacionales","Abogado", "Programador Financiero",
    "Programador en Seguridad de Redes","Jefe de Finanzas",
    "Licenciatura en Diseño Grafico","Inversionista Bancario","Jefe de Seguridad Cibernetica"," Creador de Videojuegos","Tecnologías de la Informacion","Diseño industrial",
    "Ingeniería de software","Ingeniería Aeronáutica","Ingeniería Mecatrónica",
    "Robotica","Ciencias Computacionales","Cibernetica","Relaciones Publicas","Marketing y Multimedia","Administracion financiera","Oficina Financiera"}; 


String[] Tecnología={"Desarrollador FrontEnd","Project Manager","Tecnico  Instalador de Circuitos Eléctricos","Programador Backend","Project Manager",
    "Soporte Tecnico","Analista Comercial","Analista de Sistemas","Testeo de Software"};
String[] Economía={"Contador","Asesor Financiero","Cajero Valuador","Auxiliar de Nóminas","Asesor Patrimonial",
    "Auditor","Banquero","Analista Financiero","Bolsa de Valores"};
String[] Administracion={"Coordinador de Compras","Ejecutivo en Logística","Coordinador de Call Center","Asistente Administrativo","Supervisor","Auxiliar Administrativo",
    "Ejecutivo de Reclutamiento","Recursos Humanos","Comprtamiento Organizacional"};
String[] Marketing={"Gerente de Marketing","Diseñador Grafico JR","Community Manager","Social Media Manager","Especialista en Marketing Digital",
    "Coordinador de Marketing","Asistente de Diseñador","Diseñador de Moda","Diseñador Grafico"};
public static String educacion[]= new String [9];

    public String[] colocar_datos(String valor, String[] arreglo){
for (int i = 0; i < arreglo.length; i++) {
    
        if (arreglo[i] == null) {
            arreglo[i] = valor;
            return arreglo; // Se pudo almacenar el dato, salir del método
        }
    }
    
   return arreglo;
       
    }


public String[] aplicacion(String[] Arreglo,int valor){
    In_Habilidades trae =new In_Habilidades();
    In_Educativa p = new In_Educativa();
    int repetir=-1;
    for(int i=0;i<trae.intercambio.length;i++){
        
        
        
        
        
   if(trae.intercambio[valor].equals(oferta[1])|| trae.intercambio[valor].equals(oferta[3])||trae.intercambio[valor].equals(oferta[6])||trae.intercambio[valor].equals(oferta[10])||
           trae.intercambio[valor].equals(oferta[12])||trae.intercambio[valor].equals(oferta[21])||
           trae.intercambio[valor].equals(oferta[26])||trae.intercambio[valor].equals(oferta[27])||trae.intercambio[valor].equals(oferta[29])||
           trae.intercambio[valor].equals(oferta[30])||trae.intercambio[valor].equals(oferta[31])||trae.intercambio[valor].equals(oferta[32])||trae.intercambio[valor].equals(oferta[33])||
           trae.intercambio[valor].equals(oferta[34])){

        for (int j = 0; j < Arreglo.length; j++) {
            int random=0;
           
            random=(int) (Math.random()*9-0);
            if (Arreglo[j] == null) {
            
            Arreglo[j] = Tecnología[random];
           
        }
        
        }
    if(Arreglo[0].equals(Arreglo[1])){
        int r=0;
        r=(int) (Math.random()*9-0);
        Arreglo[0]=Tecnología[r];
    }if(Arreglo[0].equals(Arreglo[2])){
        int r=0;
        r=(int) (Math.random()*9-0);
        Arreglo[2]=Tecnología[r];
    }if(Arreglo[1].equals(Arreglo[2])){
        int r=0;
        r=(int) (Math.random()*9-0);
        Arreglo[1]=Tecnología[r];
    }
    }
   
   
   
   
   
   
   
   
   
    if(trae.intercambio[valor].equals(oferta[2])|| trae.intercambio[valor].equals(oferta[18])||trae.intercambio[valor].equals(oferta[20])||trae.intercambio[valor].equals(oferta[22])||
           trae.intercambio[valor].equals(oferta[24])||trae.intercambio[valor].equals(oferta[35])||trae.intercambio[valor].equals(oferta[37])||trae.intercambio[valor].equals(oferta[38])){
        for (int j = 0; j < Arreglo.length; j++) {
            int random=0;
           
            random=(int) (Math.random()*9-0);
            if (Arreglo[j] == null) {
            
            Arreglo[j] = Economía[random];
           
        }
        
        }
    if(Arreglo[0].equals(Arreglo[1])){
        int r=0;
        r=(int) (Math.random()*9-0);
        Arreglo[0]=Economía[r];
    }if(Arreglo[0].equals(Arreglo[2])){
        int r=0;
        r=(int) (Math.random()*9-0);
        Arreglo[2]=Economía[r];
    }if(Arreglo[1].equals(Arreglo[2])){
        int r=0;
        r=(int) (Math.random()*9-0);
        Arreglo[1]=Economía[r];
    }
        
    }
   
   
   
   
   
    
    
    
    
    
    
      if(trae.intercambio[valor].equals(oferta[5])|| trae.intercambio[valor].equals(oferta[7])||trae.intercambio[valor].equals(oferta[14])||trae.intercambio[valor].equals(oferta[19])||
           trae.intercambio[valor].equals(oferta[25])){
          
          
          for (int j = 0; j < Arreglo.length; j++) {
            int random=0;
           
            random=(int) (Math.random()*9-0);
            if (Arreglo[j] == null) {
            
            Arreglo[j] = Administracion[random];
           
        }
        
        }
    if(Arreglo[0].equals(Arreglo[1])){
        int r=0;
        r=(int) (Math.random()*9-0);
        Arreglo[0]=Administracion[r];
    }if(Arreglo[0].equals(Arreglo[2])){
        int r=0;
        r=(int) (Math.random()*9-0);
        Arreglo[2]=Administracion[r];
    }if(Arreglo[1].equals(Arreglo[2])){
        int r=0;
        r=(int) (Math.random()*9-0);
        Arreglo[1]=Administracion[r];
    }
          
      }  
      
      
      
      
      
       if(trae.intercambio[valor].equals(oferta[0])|| trae.intercambio[valor].equals(oferta[4])||trae.intercambio[valor].equals(oferta[7])||trae.intercambio[valor].equals(oferta[9])||
           trae.intercambio[valor].equals(oferta[12])||trae.intercambio[valor].equals(oferta[15])||trae.intercambio[valor].equals(oferta[16])||trae.intercambio[valor].equals(oferta[17])||
           trae.intercambio[valor].equals(oferta[23])||trae.intercambio[valor].equals(oferta[28])){
          
          
          for (int j = 0; j < Arreglo.length; j++) {
            int random=0;
           
            random=(int) (Math.random()*9-0);
            if (Arreglo[j] == null) {
            
            Arreglo[j] = Marketing[random];
           
        }
        
        }
    if(Arreglo[0].equals(Arreglo[1])){
        int r=0;
        r=(int) (Math.random()*9-0);
        Arreglo[0]=Marketing[r];
    }if(Arreglo[0].equals(Arreglo[2])){
        int r=0;
        r=(int) (Math.random()*9-0);
        Arreglo[2]=Marketing[r];
    }if(Arreglo[1].equals(Arreglo[2])){
        int r=0;
        r=(int) (Math.random()*9-0);
        Arreglo[1]=Marketing[r];
    }
          
      }  
    }

        
    
    
    
    
    return Arreglo;
}


        


}




    




