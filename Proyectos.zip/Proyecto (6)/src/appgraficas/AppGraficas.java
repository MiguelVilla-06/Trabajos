package appgraficas;

import java.awt.Color;
import java.awt.Dimension;
import java.io.IOException;
import javax.swing.JFrame;

public class AppGraficas extends JFrame {
    public AppGraficas() throws IOException{
         
        this.setTitle("GRAFICA");
      
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Dimension d = new Dimension(700,530);
        this.setPreferredSize(d);
      
        
        Lienzo p= new Lienzo();
        
        this.add(p);
        this.pack();
        this.setVisible(true);
        
    }
    
    public static void main(String[] args) throws IOException {
    
     AppGraficas a = new AppGraficas(); 
     
     // doble objeto, por eso 2 jframes new AppGraficas().setVisible(true);
     

    }
    
}
