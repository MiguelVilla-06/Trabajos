package ex_correcto;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Ex_correcto {

    public static void main(String[] args) {
         JFrame marco= new JFrame("Triangulo");
marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
MiPanel p= new MiPanel();
marco.add(p);
marco.pack();
marco.setVisible(true);
    }
    
}
class Tablero{
private int filas, columnas;
private int x,y;
private int w,h;
    public Tablero() {
    }
    public Tablero(int filas,int columnas){
        this.filas=filas;
        this.columnas=columnas;
    }
    public void setSize(int w,int h){
        this.h=h;
        this.w=w;
    }
    public void setPosicion(int x,int y){
        this.x=x;
        this.y=y;
        
    }
    
     public void dibujar(Graphics g){
         int xi=0;
     for(int i=0;i<filas;i++){
         xi=x;
     for (int k=0;k<columnas;k++)
     {
         g.drawRect(xi, y, w, h);
         xi=xi+w;
     }
     y=y+h;
     }
     
     
     }    
}

class MiPanel extends JPanel{
    public MiPanel(){
    this.setPreferredSize(new Dimension(500,400));
    this.setBackground(Color.yellow);  }
    
    @Override
    public void paintComponent(Graphics g){
       super.paintComponent(g);
       Tablero t=new Tablero(480,480);
       t.setSize(2,2);
       t.setPosicion(50, 50);
       t.dibujar(g);
       
    }
}