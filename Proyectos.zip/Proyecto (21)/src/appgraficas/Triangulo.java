package appgraficas;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.GeneralPath;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;

public class Triangulo implements Shape{
    private GeneralPath ruta;
    public Triangulo(){
        
    }
    public Triangulo(double x,double y , double w, double h){
    ruta = new GeneralPath();
    ruta.moveTo(x+w*0.5, y);
    ruta.lineTo(x+w, y+h);
    ruta.lineTo(x, y+h);
    //ruta.curveTo(x+20, y+20, x, y, x, y);
    //ruta.quadTo(x+30, y+30, x, y);
    ruta.closePath();
    
    }
        
    

    @Override
    public Rectangle getBounds() {
     return ruta.getBounds();
   
    }

    @Override
    public Rectangle2D getBounds2D() {
        return ruta.getBounds2D();
         }

    @Override
    public boolean contains(double x, double y) {
        return ruta.contains(x, y);
    }

    @Override
    public boolean contains(Point2D p) {
      return ruta.contains(p);
    }

    @Override
    public boolean intersects(double x, double y, double w, double h) {
       return ruta.intersects(x, y, w, h);
    }

    @Override
    public boolean intersects(Rectangle2D r) {
       return ruta.intersects(r);
    }

    @Override
    public boolean contains(double x, double y, double w, double h) {
        return ruta.contains(x, y, w, h);
    }

    @Override
    public boolean contains(Rectangle2D r) {
        return ruta.contains(r);
    }

    @Override
    public PathIterator getPathIterator(AffineTransform at) {
        return ruta.getPathIterator(at);
    }

    @Override
    public PathIterator getPathIterator(AffineTransform at, double flatness) {
       return ruta.getPathIterator(at, flatness);
    }
}
