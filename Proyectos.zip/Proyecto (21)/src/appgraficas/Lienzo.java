package appgraficas;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Label;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Lienzo extends JPanel implements MouseListener,MouseMotionListener,KeyListener{
    
    Rectangle2D marco,h,o,l,a;
    private boolean pri,seg,ter,cua;
    private boolean lug1,lug2,lug3,lug4;
    private int xh,yh,xo,yo,xl,yl,xa,ya;
    
            
    
    
    
                                                  //CONSTRUCTOR
    public Lienzo(){
//ANULAR EL LAYOUT DEL PANEL
    this.setLayout(null);                                       //AÑADIR LOS COMPONENTES AL PANEL
    this.addMouseListener(this);
    this.addMouseMotionListener(this);
    this.addKeyListener(this);
    this.setFocusable(true);
    this.setBackground(Color.white);
     
    
    xh=240;
    yh=300;
    xo=100;
    yo=300;
    xl=310;
    yl=300;
    xa=170;
    ya=300;
    marco= new Rectangle2D.Double(100, 100, 350, 100);
    h= new Rectangle2D.Double(xh, yh, 60, 80);
    o= new Rectangle2D.Double(xo, yo, 60, 80);
    l= new Rectangle2D.Double(xl, yl, 60, 80);
    a= new Rectangle2D.Double(xa, ya, 60, 80);
    
    }  
    
    @Override
    public void paintComponent(Graphics g){
    super.paintComponent(g);
    Graphics2D g2=(Graphics2D)g;//MOTOR DE RENDER
    g2.draw(marco);
    g2.draw(h);
    g2.draw(o);
    g2.draw(l);
    g2.draw(a);
    Font f=new Font("Arial",Font.BOLD,40);
    g2.setFont(f);
    g2.drawString("H", xh+15, yh+50);
    g2.drawString("O", xo+15, yo+50);
    g2.drawString("L", xl+15, yl+50);
    g2.drawString("A", xa+15, ya+50);
    if(marco.contains(h) && xh<xo && xh<xl && xh<xa){
        lug1=true;
    }else{
        lug1=false;
    }
    if(marco.contains(o) && xo<xl && xo<xa ){
        lug2=true;
    }else{
        lug2=false;
    }
    if(marco.contains(l) && xl<xa){
        lug3=true;
    }else{
        lug3=false;
    }
    if(marco.contains(a)){
        lug4=true;
    }else{
        lug4=false;
    }
    if(lug1==true && lug2==true &&lug3==true&&lug4==true){
        g2.drawString("LO LOGRASTE", 200, 300);
        
    }
    

    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
 if(h.contains(e.getPoint())){
     pri=true;
     seg=false;
     ter=false;
     cua=false;
     System.out.println(pri);
 }
 if(o.contains(e.getPoint())){
     pri=false;
     seg=true;
     ter=false;
     cua=false;
 }
 if(l.contains(e.getPoint())){
     pri=false;
     seg=false;
     ter=true;
     cua=false;
 }
 if(a.contains(e.getPoint())){
     pri=false;
     seg=false;
     ter=false;
     cua=true;
 }
    }
    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseDragged(MouseEvent e) {//metodo de arrastar
       
    }

    @Override
    public void mouseMoved(MouseEvent e) {//metodo de arrastrar
            }

    @Override
    public void keyTyped(KeyEvent e) {
       
    }

    @Override
    public void keyPressed(KeyEvent e) {
         if(pri==true){
            if(e.getKeyCode()==KeyEvent.VK_UP){
                yh=yh-15;
                h= new Rectangle2D.Double(xh, yh, 60, 80);
                repaint();
            }
            if(e.getKeyCode()==KeyEvent.VK_DOWN){
                yh=yh+15;
                h= new Rectangle2D.Double(xh, yh, 60, 80);
                repaint();
            }
            if(e.getKeyCode()==KeyEvent.VK_RIGHT){
                xh=xh+15;
                h= new Rectangle2D.Double(xh, yh, 60, 80);
                repaint();
            }
            if(e.getKeyCode()==KeyEvent.VK_LEFT){
                xh=xh-15;
                h= new Rectangle2D.Double(xh, yh, 60, 80);
                repaint();
            }
        }
         
         
         if(seg==true){
            if(e.getKeyCode()==KeyEvent.VK_UP){
                yo=yo-15;
                o= new Rectangle2D.Double(xo, yo, 60, 80);
                repaint();
            }
            if(e.getKeyCode()==KeyEvent.VK_DOWN){
                yo=yo+15;
                o= new Rectangle2D.Double(xo, yo, 60, 80);
                repaint();
            }
            if(e.getKeyCode()==KeyEvent.VK_RIGHT){
                xo=xo+15;
                o= new Rectangle2D.Double(xo, yo, 60, 80);
                repaint();
            }
            if(e.getKeyCode()==KeyEvent.VK_LEFT){
                xo=xo-15;
                o= new Rectangle2D.Double(xo, yo, 60, 80);
                repaint();
            }
        }
         
         
         if(ter==true){
            if(e.getKeyCode()==KeyEvent.VK_UP){
                yl=yl-15;
                l= new Rectangle2D.Double(xl, yl, 60, 80);
                repaint();
            }
            if(e.getKeyCode()==KeyEvent.VK_DOWN){
                yl=yl+15;
                l= new Rectangle2D.Double(xl, yl, 60, 80);
                repaint();
            }
            if(e.getKeyCode()==KeyEvent.VK_RIGHT){
                xl=xl+15;
                l= new Rectangle2D.Double(xl, yl, 60, 80);
                repaint();
            }
            if(e.getKeyCode()==KeyEvent.VK_LEFT){
                xl=xl-15;
                l= new Rectangle2D.Double(xl, yl, 60, 80);
                repaint();
            }
        }
         
         
         
         if(cua==true){
            if(e.getKeyCode()==KeyEvent.VK_UP){
                ya=ya-15;
                a= new Rectangle2D.Double(xa, ya, 60, 80);
                repaint();
            }
            if(e.getKeyCode()==KeyEvent.VK_DOWN){
                ya=ya+15;
                a= new Rectangle2D.Double(xa, ya, 60, 80);
                repaint();
            }
            if(e.getKeyCode()==KeyEvent.VK_RIGHT){
                xa=xa+15;
                a= new Rectangle2D.Double(xa, ya, 60, 80);
                repaint();
            }
            if(e.getKeyCode()==KeyEvent.VK_LEFT){
                xa=xa-15;
                a= new Rectangle2D.Double(xa, ya, 60, 80);
                repaint();
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }

}
