package proyecto_2;
import java.util.Scanner;
public class Proyecto_2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int numero1=0,numero2=0,numero3=0;
        
        System.out.println("Dame un numero A");
        Scanner numero = new Scanner (System.in);
        numero1=numero.nextInt();
        System.out.println("No. B");
        numero2=numero.nextInt();
        System.out.println("No. C");
        numero3=numero.nextInt();
        
        
        if(numero1>numero2){
        if (numero1>numero3){
            System.out.println("A es mayor");}}
        
        if(numero2>numero1){
        if(numero2>numero3){
            System.out.println("B es mayor");}}
        if(numero3>numero1){
        if(numero3>numero2){
            System.out.println("C es mayor");}
        }
    }
}
