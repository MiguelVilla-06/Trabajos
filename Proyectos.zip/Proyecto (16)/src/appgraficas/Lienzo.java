package appgraficas;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Lienzo extends JPanel implements MouseListener,MouseMotionListener,KeyListener{
    private double y,x;    
    public boolean parar;//ATRIBUTOS
    GeneralPath linea;
    Rectangle2D rec1;
    
    
    
    
                                                  //CONSTRUCTOR
    public Lienzo(){
     
        
    linea=new GeneralPath();    
        
//ANULAR EL LAYOUT DEL PANEL
    this.setLayout(null);
                                                  //COLOCAR CADA COMPONENTE EN LA POSICION DESEADA
                                                  //AÑADIR LOS COMPONENTES AL PANEL
    this.addMouseListener(this);
    this.addMouseMotionListener(this);
    this.addKeyListener(this);
    this.setFocusable(true);
    this.setBackground(Color.white);
       
       
    }  
    
    @Override
    public void paintComponent(Graphics g){
    super.paintComponent(g);
    Graphics2D g2=(Graphics2D)g;//MOTOR DE RENDER
    
    g2.draw(linea);
  
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
        x=e.getX();
        y=e.getY();
        linea.moveTo(x, y);
        repaint();
         parar=true;
    }
    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseDragged(MouseEvent e) {//metodo de arrastar
       
    }

    @Override
    public void mouseMoved(MouseEvent e) {//metodo de arrastrar
            }

    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
       if(parar==true){
       if(e.getKeyCode()==KeyEvent.VK_UP){
       y=y-5;
       linea.lineTo(x, y);
       
       repaint();
           System.out.println("Si pasa");
       }
       if(e.getKeyCode()==KeyEvent.VK_DOWN){
           y=y+5;
           linea.lineTo(x, y);
          repaint();
       }
        if(e.getKeyCode()==KeyEvent.VK_RIGHT){
       x=x+5;
       linea.lineTo(x, y);
       repaint();
       }
       if(e.getKeyCode()==KeyEvent.VK_LEFT){
           x=x-5;
           linea.lineTo(x, y);
          repaint();
       }}
       if(e.getKeyCode()==KeyEvent.VK_F){
           
           parar=false;
           repaint();
       }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }

}
