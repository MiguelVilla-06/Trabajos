package proyecto;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PROYECTO {
public static void main(String[] args) {
JFrame marco= new JFrame("Colores RGB");
marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
MiPanel p= new MiPanel();
marco.add(p);
marco.pack();
marco.setVisible(true); 
    }   
}

class MiPanel extends JPanel{
    protected int v,a,r, z;
    private JComboBox cmbRojo,cmbVerde,cmbAzul;
    private JLabel lblRojo,lblVerde,lblAzul;
    private JButton boton;
    private JTextField jtxt;
    String[] cad;
   
   
    public MiPanel(){
    cmbRojo=new JComboBox();
    cmbVerde=new JComboBox();
    cmbAzul=new JComboBox();
    jtxt=new JTextField();
   
     
    
    
    lblRojo= new JLabel("Rojo");
    lblVerde= new JLabel("verde");
    lblAzul= new JLabel("Azul");
    this.setLayout(null);
    boton= new JButton("Mostrar");
    cmbRojo.setBounds(50, 20, 100, 30);
    cmbVerde.setBounds(50, 100, 100, 30);
    cmbAzul.setBounds(50, 180, 100, 30);
    lblRojo.setBounds(10, 20, 100, 30);
    lblVerde.setBounds(10, 100, 100, 30);
    lblAzul.setBounds(10, 180, 100, 30);
    boton.setBounds(300, 300, 100, 30);
    jtxt.setBounds(300, 20, 100, 30);
    
    this.add(cmbRojo);
    this.add(cmbVerde);
    this.add(cmbAzul);
    this.add(lblRojo);
    this.add(lblVerde);
    this.add(lblAzul);
    this.add(boton);
    this.add(jtxt);
    for(int i=0;i<256;i++){
      cmbRojo.addItem(i);
      cmbVerde.addItem(i);
      cmbAzul.addItem(i);
      
    }
    
    boton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
          r= (int) cmbRojo.getSelectedItem();
          v= (int) cmbVerde.getSelectedItem();
          a= (int) cmbAzul.getSelectedItem();
          
        
         
         cad= jtxt.getText().split(",");
         z=cad.length;
          repaint();
        }
    });
    this.setPreferredSize(new Dimension(1000,1000));
    this.setBackground(Color.yellow);  
    }
    
    
    @Override
    public void paintComponent(Graphics g){
    super.paintComponent(g);
    
    g.drawLine(50,200,50,450);
    g.drawLine(25,400,475,400);
    
    int x=70;
    //g.fillrOval(300, 150, 100, 80);
    for(int i=0;i<z;i++){
        g.setColor(new Color(r,v,a));
        g.fillRect(x,400-Integer.parseInt(cad[i]),10, Integer.parseInt(cad[i])); 
              x=x+100;
    }
      
       
       
       
    }
   
}


