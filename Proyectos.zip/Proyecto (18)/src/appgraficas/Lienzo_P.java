package appgraficas;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.Timer;

public class Lienzo_P extends JPanel implements KeyListener {
    private boolean re1,re2,partido;
    private AffineTransform ax;
    private double y1,y2,r1,r2;
    private Shape eli;
    private JPanel panel;
    private Shape rec1, rec2;
    private int m1,m2;
    
    
    
    public Lienzo_P(){
    this.setLayout(null); 
    this.setFocusable(true);
    this.setBackground(Color.white);
    this.addKeyListener(this);
    panel=this;
    ax = new AffineTransform();
   
    partido=true;
    ax.setToTranslation(5, 0);
    y1=60;
    y2=60;
    m1=0;
    m2=0;
    eli= new Ellipse2D.Double(200,200,50,50);
    rec1= new Rectangle2D.Double(20,y1,20,100);
    rec2= new Rectangle2D.Double(600,y2,20,100);
    
    Timer t = new Timer(1, new ActionListener() {
        @Override
        
    public void actionPerformed(ActionEvent e) {
        if(eli.intersects((Rectangle2D) rec1)){
           re1=true;
           re2=false;
            r1=Math.random() * 11 - 5;
            r2=Math.random() * 11 - 5;
           ax.setToTranslation(7, r1);
            repaint();
        } else if(eli.intersects((Rectangle2D) rec2)){
            re1=false;
            re2=true;
            ax.setToTranslation(-7, -3);
            repaint();
            r1=Math.random() * 11 - 5;
            r2=Math.random() * 11 - 5;
        }
           if(re1){
        
        if(eli.getBounds2D().getY()-50>panel.getHeight()-50 ){
            ax.setToTranslation(7, -3);
            repaint();
         
        } 
        if(eli.getBounds2D().getY()-50<0 ){
            ax.setToTranslation(7, 3);
            repaint();
         
        }}
        
        if(re2){
        
        if(eli.getBounds2D().getY()-50>panel.getHeight()-50 ){
            ax.setToTranslation(-7, -3);
            repaint();
         
        } 
        if(eli.getBounds2D().getY()-50<0 ){
            ax.setToTranslation(-7, 3);
            repaint();
         
        }
           }
        
        
         if(eli.getBounds2D().getX()>panel.getWidth()-50 && partido==true){
            m1=m1+1;
            System.out.println("JUGADOR 1: "+ m1);
            System.out.println("JUGADOR 2: "+ m2);
           partido=false;
           ax.setToTranslation(-1, 0);
        }
    if(eli.getBounds2D().getX()<0 && partido==true){
            m2=m2+1;
            System.out.println("JUGADOR 1: "+ m1);
            System.out.println("JUGADOR 2: "+ m2);
            partido=false;
           ax.setToTranslation(1, 0);
        }
         repaint();

        }
   
    });
    t.start();
   
    }  
    
    
    @Override
    public void paintComponent(Graphics g){
    super.paintComponent(g);
    Graphics2D g2=(Graphics2D)g;//MOTOR DE RENDER
    eli=ax.createTransformedShape(eli);
    Font f=new Font("Arial",Font.BOLD,40);
    g2.setFont(f); 
    if(partido==true){
    g2.fill(eli);
    } else if(partido==false){
     g2.drawString("JUGADOR 1: " +m1, 270, 200);
     g2.drawString("JUGADOR 2: " +m2, 270, 300);
    }
    g2.fill(rec1);
    g2.fill(rec2);
    
    }

    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
       if(e.getKeyCode()== KeyEvent.VK_UP){
          y2=y2-15;
          rec2= new Rectangle2D.Double(600,y2,20,100);
          repaint();
      }
       if(e.getKeyCode()==KeyEvent.VK_DOWN){
                y2=y2+15;
                rec2= new Rectangle2D.Double(600, y2, 20, 100);
                repaint();
            }
       
       
       if(e.getKeyCode()== KeyEvent.VK_W){
          y1=y1-15;
          rec1= new Rectangle2D.Double(20,y1,20,100);
          repaint();
      }
       if(e.getKeyCode()== KeyEvent.VK_S){
          y1=y1+15;
          rec1= new Rectangle2D.Double(20,y1,20,100);
          repaint();
          
      }
    
      if(e.getKeyCode()== KeyEvent.VK_A){
          partido=true;
      }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    
    
}
