package appgraficas;

import java.awt.Dimension;
import javax.swing.JFrame;

public class AppGraficas extends JFrame {
    public AppGraficas(){
         
        this.setTitle("GRAFICA");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Dimension d = new Dimension(700,500);
        this.setPreferredSize(d);
        Lienzo_P p= new Lienzo_P();
        this.add(p);
        this.pack();
        this.setVisible(true);
        
    }
    
    public static void main(String[] args) {
    
     AppGraficas a = new AppGraficas(); 
     
     // doble objeto, por eso 2 jframes new AppGraficas().setVisible(true);
     

    }
    
}
