package appgraficas;

import java.awt.Graphics;

public class Asignar {
    
    public Asignar(){
        
    }
    public Asignar(int x){
    
    }
    public void Dibujar(Graphics g){
   
        
    }
}
