package appgraficas;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Lienzo extends JPanel implements MouseListener,MouseMotionListener{
                                                  //ATRIBUTOS
    //private double ;
    private String Guardar="no" ;
    //boolean ;
    Rectangle2D azul;
    Rectangle2D azul1;
    Rectangle2D rojo;
    Rectangle2D rojo1;
    Rectangle2D verde;
    Rectangle2D verde1;
    private boolean arrastrar,arrastrar2,arrastrar3;
    private int dx,dy;
    private boolean azu,roj,ver;
    private int xa,xr,xv,y1,y2;
    
                                                  //CONSTRUCTOR
    public Lienzo(){
                                                  //ANULAR EL LAYOUT DEL PANEL
    this.setLayout(null);
                                                  //COLOCAR CADA COMPONENTE EN LA POSICION DESEADA
                                                  //AÑADIR LOS COMPONENTES AL PANEL
    this.addMouseListener(this);
    this.addMouseMotionListener(this);
    xa=20;
    xr=130;
    xv=250;
    y1=20;
    y2=150;
    this.setBackground(Color.white);
       azul= new Rectangle2D.Double(xa,y1,100,100); 
       azul1= new Rectangle2D.Double(xa,y2,80,80);
       rojo= new Rectangle2D.Double(xr,y1,100,100);
       rojo1= new Rectangle2D.Double(xr,y2,80,80);
       verde= new Rectangle2D.Double(xv,y1,100,100);
       verde1= new Rectangle2D.Double(xv,y2,80,80);
       
    }  
    
    @Override
    public void paintComponent(Graphics g){
    super.paintComponent(g);
    Graphics2D g2=(Graphics2D)g;//MOTOR DE RENDER
    Color a= new Color(0,0,250,250);// color no usado
    Color r= new Color(250,0,0,250);
    Color v= new Color(0,250,0,250);
    

//GradientPaint a= new GradientPaint(280,230,Color.YELLOW,320,260,Color.BLUE);//color de relleno 2d
    g2.setPaint(a);//pintar g2 con el color a
    g2.draw(azul);//pintar g2 con el color a
    g2.fill(azul1);
    g2.setPaint(r);//pintar g2 con el color a
    g2.draw(rojo);//pintar g2 con el color a
    g2.fill(rojo1);
    g2.setPaint(v);//pintar g2 con el color a
    g2.draw(verde);//pintar g2 con el color a
    g2.fill(verde1);
    
    Font f= new Font("Arial",Font.BOLD,20);
    g2.setFont(f);
    g2.drawString(Guardar,200,300);
      //   g2.draw(objeto a dibujar);
  
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
         if(azul1.contains(e.getPoint())){
        arrastrar=true;
         dx=(int) (e.getX()-azul1.getX());
         dy=(int) (e.getY()-azul1.getY());
         }
         if(verde1.contains(e.getPoint())){
        arrastrar2=true;
         dx=(int) (e.getX()-verde1.getX());
         dy=(int) (e.getY()-verde1.getY());
         }
         if(rojo1.contains(e.getPoint())){
        arrastrar3=true;
         dx=(int) (e.getX()-rojo1.getX());
         dy=(int) (e.getY()-rojo1.getY());
         }
         
    }
    @Override
    public void mouseReleased(MouseEvent e) {
        arrastrar=false;
        arrastrar2=false;
        arrastrar3=false;
        if(azul.contains(azul1)){
            azu=true;
            azul1.setFrame(azul);
        }else{
            azu=false;
             azul1= new Rectangle2D.Double(20,150,80,80);
            repaint();
        }
         if(verde.contains(verde1)){
            ver=true;
            verde1.setFrame(verde);
        }else{
          ver=false;
          verde1= new Rectangle2D.Double(250,150,80,80);
            repaint();
        }
          if(rojo.contains(rojo1)){
            roj=true;
            rojo1.setFrame(rojo);
        }else{
            roj=false;
            rojo1= new Rectangle2D.Double(130,150,80,80);
            repaint();
        }
        
        if(roj==true && ver==true && azu==true){
            System.out.println("Si tilin");
            Guardar="ERES INCREIBLE MY LIC :)";
            repaint();
        
        }
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseDragged(MouseEvent e) {//metodo de arrastar
         if(arrastrar==true && azu==false){
            azul1.setFrame(e.getX()-dx, e.getY()-dy, 80, 80);
            repaint();  
        }
         if(arrastrar2==true && ver==false){
             verde1.setFrame(e.getX()-dx, e.getY()-dy, 80, 80);
             repaint();
         }
         if(arrastrar3==true && roj==false){
           rojo1.setFrame(e.getX()-dx, e.getY()-dy, 80, 80);
           repaint();
         }
    }

    @Override
    public void mouseMoved(MouseEvent e) {//metodo de arrastrar
            }

}
