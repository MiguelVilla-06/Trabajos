package proyecto_8;
public class Proyecto_8 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {   
    Rectangle r=new Rectangle(10,20,100,80);
    System.out.println("x= "+r.getX());
    System.out.println("y= "+r.getY());
    System.out.println("h= "+r.getH());
    System.out.println("w= "+ r.getW());
    System.out.println("A= "+r.getArea());    
    }
    
}

class Shape{
private int x,y;
public Shape(){
x=0;
y=0;
}
public Shape(int x,int y){
this.x=x;
this.y=y;
}
    public int getX() {return x;}

    public void setX(int x) {this.x = x;}

    public int getY() {return y;}

    public void setY(int y) {this.y = y;}
}

class Rectangle extends Shape{
private int w,h;
public Rectangle(){
super();
w=0;
h=0;
}
public Rectangle(int x, int y, int w ,int h){
    super(x,y);
    this.w=w;
    this.h=h;
    
}

    public int getW() {return w;}
    public void setW(int w) {this.w = w;}
    public int getH() { return h;}
    public void setH(int h) {this.h = h;}

    public int getArea(){
        return w*h;
    }
    
    
}





