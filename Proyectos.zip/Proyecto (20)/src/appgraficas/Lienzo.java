package appgraficas;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.Timer;

public class Lienzo extends JPanel implements KeyListener {

    private Shape eli1,eli2,eli3;
    private boolean fin1,fin2,fin3;
    private JPanel panel;
    private Shape rec;
    private int m1,m2;
    private AffineTransform ax1,ax2,ax3;
    private double x1,y1,x2,y2,x3,y3,xr;
    private Image img,img2,img3,img4;
    
    public Lienzo() throws IOException{
    
    panel=this;
    ax1= new AffineTransform();
    ax2= new AffineTransform();
    ax3= new AffineTransform();
    this.setLayout(null); 
    this.setFocusable(true);
    this.setBackground(Color.white);
    this.addKeyListener(this);
    
    img=ImageIO.read(new File("violencia3.jpg"));
    img2=ImageIO.read(new File("violencia1.jpg"));
    img3=ImageIO.read(new File("violencia1.jpg"));
    img4=ImageIO.read(new File("violencia1.jpg"));
    
    x1=Math.random()*700 + 1;
    x2=Math.random()*700 + 1;
    x3=Math.random()*700 + 1;
    y1=Math.random()*50 + 1;
    y2=Math.random()*50 + 1;
    y3=Math.random()*50 + 1;
    xr=350;
    eli1= new Ellipse2D.Double(x1,y1,20,20);
    eli2= new Ellipse2D.Double(x2,y2,20,20);
    eli3= new Ellipse2D.Double(x3,y3,20,20);
    rec= new Rectangle2D.Double(xr,410,60,20);
    
     ax1.setToTranslation(0, 3);
     ax2.setToTranslation(0, 3);
     ax3.setToTranslation(0, 3);

    fin1=true;
    fin2=true;
    fin3=true;
    
    Timer t = new Timer(10, new ActionListener() {
        @Override
        
    public void actionPerformed(ActionEvent e) {
       
        x1=eli1.getBounds().x;
        y1=eli1.getBounds().y;
        
        x2=eli2.getBounds().x;
        y2=eli2.getBounds().y;
        
        x3=eli3.getBounds().x;
        y3=eli3.getBounds().y;
        repaint();
        
        if(eli1.intersects((Rectangle2D) rec)){
           ax1.setToTranslation(0, -3);
           
           repaint(); 
        }
        if(eli2.intersects((Rectangle2D) rec)){
           ax2.setToTranslation(0, -3);
           repaint(); 
        }
        if(eli3.intersects((Rectangle2D) rec)){
           ax3.setToTranslation(0, -3);
           repaint(); 
        }
        if(eli1.getBounds2D().getY()-10<0 ){
            ax1.setToTranslation(0, 3);
            repaint();
        }
        if(eli2.getBounds2D().getY()-10<0 ){
            ax2.setToTranslation(0, 3);
            repaint();
        }
        if(eli3.getBounds2D().getY()-10<0 ){
            ax3.setToTranslation(0, 3);
            repaint();
        }
        
            
        if(eli1.getBounds2D().getY()>panel.getHeight()-30 ){
            eli1= new Ellipse2D.Double(0,0,0,0);
            fin1=false;
            img=null;
        }
        if(eli2.getBounds2D().getY()>panel.getHeight()-30 ){
            eli2= new Ellipse2D.Double(0,0,0,0);
            fin2=false;
            img2=null;
        }
        if(eli3.getBounds2D().getY()>panel.getHeight()-30 ){
            eli3= new Ellipse2D.Double(0,0,0,0);
            fin3=false;
            img3=null;
        }
        repaint();
        }
    
    });
    t.start();
   
    }  
    
    
    @Override
    public void paintComponent(Graphics g){
    super.paintComponent(g);
    Graphics2D g2=(Graphics2D)g;//MOTOR DE RENDER
    eli1=ax1.createTransformedShape(eli1);
    eli2=ax2.createTransformedShape(eli2);
    eli3=ax3.createTransformedShape(eli3);
  
    
    g2.draw(rec);
    g2.draw(eli1);
    g2.draw(eli2);
    g2.draw(eli3);
    
    g2.drawImage(img, (int)x1, (int)y1, 20, 20, this);
    g2.drawImage(img2, (int)x2, (int)y2, 20, 20, this);
    g2.drawImage(img3, (int)x3, (int)y3, 20, 20, this);
    g2.drawImage(img4, (int)xr, 410, 60, 20, this);
    
    Font f=new Font("Arial",Font.BOLD,40);
    g2.setFont(f); 
    if(fin1==false && fin2==false && fin3==false){
        g2.drawString("PERDISTE :( PIPIPIPIPI", 200, 300);
    }
    }

    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
      if(e.getKeyCode()== KeyEvent.VK_LEFT){
          xr=xr-15;
          rec= new Rectangle2D.Double(xr,410,60,20);
          
          repaint();
          
      }
       if(e.getKeyCode()==KeyEvent.VK_RIGHT){
                xr=xr+15;
                rec= new Rectangle2D.Double(xr, 410, 60, 20);
                repaint();
            }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    
    
}
