package appgraficas;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Stroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.GeneralPath;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Dibujo extends JPanel implements MouseListener,MouseMotionListener,KeyListener{
   private ArrayList<Point> puntos;
   private Color co;
   private int str;
   
   
    
                                           //CONSTRUCTOR
    public Dibujo(){
        
//ANULAR EL LAYOUT DEL PANEL
    this.setLayout(null);
                                                  //COLOCAR CADA COMPONENTE EN LA POSICION DESEADA
                                                  //AÑADIR LOS COMPONENTES AL PANEL
    this.addMouseListener(this);
    //this.addMouseMotionListener(this);
    this.addKeyListener(this);
    this.setFocusable(true);
    this.setBackground(Color.white);
     
    puntos= new ArrayList<>();
    
    
    }  
    
    @Override
    public void paintComponent(Graphics g){
    
    super.paintComponent(g);
    Graphics2D g2=(Graphics2D)g;//MOTOR DE RENDER
  
    if( puntos.size()>1 ){
        for(int i=0;i<puntos.size()-1;i++){
            
            Linea l=new Linea(str,co,puntos.get(i),puntos.get(i+1));
            l.dibujar(g2);
            
        }
    }
   
  
    }

    @Override
    public void mouseClicked(MouseEvent e) {
    }

    @Override
    public void mousePressed(MouseEvent e) {
       puntos.add(e.getPoint());
       repaint(); 
       
       
    }
    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseDragged(MouseEvent e) {
       
       
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        
    }

    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(puntos.size()>puntos.size()-1){
        if(e.getKeyCode()==KeyEvent.VK_V){
            co=Color.GREEN;
            repaint();
            
        }
        if(e.getKeyCode()==KeyEvent.VK_A){
            co=Color.BLUE;
            repaint();
        }
        if(e.getKeyCode()==KeyEvent.VK_R){
            co=Color.RED;
            repaint();
        }
        if(e.getKeyCode()==KeyEvent.VK_2){
           str=2; 
        }
        if(e.getKeyCode()==KeyEvent.VK_6){
            str=6;
        }
        if(e.getKeyCode()==KeyEvent.VK_9){
           str=9;
        }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }
    

   

}
class Linea{
        private int grosor;
        private Color color;
        private Point pi,pf;
        public Linea(int g,Color c,Point pi,Point pf){
            grosor=g;
            color=c;
            this.pi=pi;
            this.pf=pf;
        }
        public void dibujar(Graphics2D g2){
            BasicStroke stroke = new BasicStroke(grosor);
            g2.setStroke(stroke);
            g2.setPaint(color);
            Line2D l= new Line2D.Double(pi,pf);
            g2.draw(l);
        }
    }
