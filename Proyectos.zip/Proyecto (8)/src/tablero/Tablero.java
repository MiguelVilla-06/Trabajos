/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tablero;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author Alumno
 */
public class Tablero {
    protected int x,y,alto,ancho,filas, columnas;
   
    
    public static void main(String[] args) {
        JFrame marco= new JFrame("Triangulo");
marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
MiPanel p= new MiPanel();
marco.add(p);
marco.pack();
marco.setVisible(true); 
    }

    
    public Tablero() {
    }
    
    public Tablero(int filas, int columnas){
        this.filas=filas;
        this.columnas=columnas;
        
    }

    public int getFilas() {
        return filas;
    }

    public void setFilas(int filas) {
        this.filas = filas;
    }

    public int getColumnas() {
        return columnas;
    }

    public void setColumnas(int columnas) {
        this.columnas = columnas;
    }
    
     public void dibujar(Graphics g){
    int inicio=x;
         for(int j=0;j<columnas;j++){
         for(int i=0;i<filas;i++){
         g.drawRect(x, y, ancho, alto);
         y=y+alto;
     }  x=x+ancho;
     if(y>=alto*filas){
         y=inicio;
     }
         }
     }
     
     public void setSize(int alto, int ancho){
         this.ancho=ancho;
         this.alto=alto;
     }
     
     public void setPosicion(int x, int y){
         this.x=x;
         this.y=y;
     }
    }
    



class MiPanel extends JPanel{
    public MiPanel(){
    this.setPreferredSize(new Dimension(500,400));
    this.setBackground(Color.yellow);  }
    
    @Override
    public void paintComponent(Graphics g){
       super.paintComponent(g);
       Tablero t=new Tablero(5,5);
       t.setSize(50,50);
       t.setPosicion(50, 50);
       t.dibujar(g);
       
    }
}
