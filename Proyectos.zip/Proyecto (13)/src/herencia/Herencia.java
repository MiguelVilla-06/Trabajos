package herencia;


public class Herencia {

    public static void main(String[] args) {
        Rectangle r = new Rectangle (10,20,100,80);
        
        
        System.out.println("Inicio: ("+r.getX()+","+r.getY()+") ");
        System.out.println("Altura: "+r.getHeight());
        System.out.println("Ancho: "+r.getWeight());
        System.out.println("Area: "+r.getArea());
       
    }
    
}

class Shape{
    
    private int x,y;
    
    public Shape(){
        x = 0;
        y = 0;
    }
    
    public Shape(int x, int y){
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
        
}

class Rectangle extends Shape{
    
    private int weight, height;
    
    public Rectangle(){
        super();
        weight = 0;
        height = 0;
    }

    public Rectangle(int x, int y, int weight, int height) {
        super(x,y);
        this.weight = weight;
        this.height = height;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }
    
    public int getArea(){
        return (weight*height);
    }
    
}
