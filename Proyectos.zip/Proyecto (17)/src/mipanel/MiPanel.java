package mipanel;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class MiPanel extends JPanel{
    private JButton boton;
    private JTextField caja;
    private String s;
    private int x;
  
    public MiPanel(){
    s="";
    
    this.setPreferredSize(new Dimension(500,400));
    this.setBackground(Color.yellow);  
    boton= new JButton("Graficar");
    caja=new JTextField();
    this.setLayout(null);
    boton.setBounds(20, 20, 100, 30);
    caja.setBounds(140, 20, 100, 30);
    this.add(boton);
    this.add(caja);
   
     
    boton.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
     s=caja.getText();
     x=Integer.parseInt(s);
     repaint();
     
     
             }
         });
   
    }
     @Override
    public void paintComponent(Graphics g){
    super.paintComponent(g);
     g.drawString(s,20,190);
        g.drawRect(150, 150, x,x);
       
    }
    
    
public static void main(String[] args) {
JFrame marco= new JFrame("Triangulo");
marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
MiPanel p= new MiPanel();
marco.add(p);
marco.pack();
marco.setVisible(true); 
    }
    
}
