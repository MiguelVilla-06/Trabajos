package pultimo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PULTIMO {
    public static void main(String[] args) {
      
    }
    class MiPanel extends JPanel{
    protected int v,a,r, z;
    private JComboBox cmbRojo,cmbVerde,cmbAzul;
    private JLabel lblRojo,lblVerde,lblAzul;
    private JButton boton;
    private JTextField jtxt;
    String[] cad;
   
   
    public MiPanel(){
    
      
    
    
    boton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
          
        
          repaint();
        }
    });
    this.setPreferredSize(new Dimension(1000,1000));
    this.setBackground(Color.yellow);  
    }
    
    
    @Override
    public void paintComponent(Graphics g){
    super.paintComponent(g);
   
    }
      
       
       
       
    }
}
