package proyecto_4;

import java.util.Scanner;

public class Proyecto_4 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Scanner scan=new Scanner(System.in);
        Punto p=new Punto();
        System.out.println("Dame el valor de x");
        p.setX(scan.nextInt());
        System.out.println("Dame el valor de y");
        p.setY(scan.nextInt());
        p.setX(10);
        p.setY(7);
        
        
        p.sumar(2,1);
        //System.out.println("x="+p.getX()+"y="+p.getY());
        Punto otro= new Punto();
        otro.sumar(3, 5);
        //System.out.println("x= "+otro.getX()+"Y="+otro.getY());
        p.imprimir();
        otro.imprimir();
   
    
    }
}

class Punto{
private int x,y;
public void sumar(int a,int b){
    x=x+a;
    y=y+b;
}

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

public void imprimir(){
    System.out.println("("+x+","+y+")");
}

}
