package appgraficas;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Lienzo extends JPanel implements MouseListener,MouseMotionListener,KeyListener{
    public double y1,x1,h1,w1;
    public double y2,x2,h2,w2; //ATRIBUTOS
    public boolean ar1,ar2,ar3,ar4;
    Rectangle2D rec1;
    Rectangle2D rec2;
    
    
    
    
                                                  //CONSTRUCTOR
    public Lienzo(){
               y1=200;  
               x1=200;
               h1=100;
               w1=100;
               x2=100;
               y2=100;
               w2=20;
               h2=20;
//ANULAR EL LAYOUT DEL PANEL
    this.setLayout(null);
                                                  //COLOCAR CADA COMPONENTE EN LA POSICION DESEADA
                                                  //AÑADIR LOS COMPONENTES AL PANEL
    this.addMouseListener(this);
    this.addMouseMotionListener(this);
    this.addKeyListener(this);
    this.setFocusable(true);
    this.setBackground(Color.white);
       
       
    }  
    
    @Override
    public void paintComponent(Graphics g){
    super.paintComponent(g);
    Graphics2D g2=(Graphics2D)g;//MOTOR DE RENDER
    rec1 = new Rectangle2D.Double(x1,y1,w1,h1);
    rec2 = new Rectangle2D.Double(x2,y2,w2,h2);
    Color a =new Color(250,0,0);
    g2.draw(rec1);
    g2.draw(rec2);
    
   
  
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        rec2=new Rectangle2D.Double(e.getX(),e.getY(),w2,h2);
        repaint();
    }

    @Override
    public void mousePressed(MouseEvent e) {
        x2=e.getX()-10;
        y2=e.getY()-10;
        rec2=new Rectangle2D.Double(x2,y2,w2,h2);
       repaint();
        
        if(rec2.contains(x1,y1)){
            x2=x1-10;
            y2=y1-10;
            rec2=new Rectangle2D.Double(x2,y2,w2,h2);
            ar1=true;
            System.out.println(ar1);
        }else{
            ar1=false;
        }
        
        if(rec2.contains(x1+w1,y1)){
            x2=x1+w1-10;
            y2=y1-10;
            rec2=new Rectangle2D.Double(x2,y2,w2,h2);
          ar2=true;
        }else{
            ar2=false;
        }
        
        if(rec2.contains(x1,y1+h1)){
            x2=x1-10;
            y2=y1+h1-10;
            rec2=new Rectangle2D.Double(x2,y2,w2,h2);
          ar3=true;
        }else{
            ar3=false;
        }
        
        if(rec2.contains(x1+w1,y1+h1)){
            x2=x1+w1-10;
            y2=y1+h1-10;
            rec2=new Rectangle2D.Double(x2,y2,w2,h2);
           ar4=true;
        }else{
            ar4=false;
        }
         
    }
    @Override
    public void mouseReleased(MouseEvent e) {
        
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }

    @Override
    public void mouseDragged(MouseEvent e) {//metodo de arrastar
       
    }

    @Override
    public void mouseMoved(MouseEvent e) {//metodo de arrastrar
            }

    @Override
    public void keyTyped(KeyEvent e) {
        
    }

    @Override
    public void keyPressed(KeyEvent e) {
        
        
        
        
        
        
        
        
        
       if(e.getKeyCode()==KeyEvent.VK_UP && ar1==true){
           h1=h1+2;
           y1=y1-2;
           y2=y2-2;
        
        rec1=new Rectangle2D.Double(x1,y1,w1,h1);
        rec2=new Rectangle2D.Double(x2, y2, w2, h2);
        repaint();
       }
       if(e.getKeyCode()==KeyEvent.VK_DOWN&& ar1==true){
        h1=h1+2;   
           
        rec1=new Rectangle2D.Double(x1,y1,w1,h1);
        repaint();
       }
        if(e.getKeyCode()==KeyEvent.VK_RIGHT&& ar1==true){
        w1=w1+2;    
        rec1=new Rectangle2D.Double(x1,y1,w1,h1);
        repaint();
       }
       if(e.getKeyCode()==KeyEvent.VK_LEFT&& ar1==true){
           x1=x1-2;
           w1=w1+2;
           x2=x2-2;
        rec1=new Rectangle2D.Double(x1,y1,w1,h1);
        repaint();
       }
       

       
       
       
       
       if(e.getKeyCode()==KeyEvent.VK_UP && ar2==true){
           h1=h1+2;
           y1=y1-2;
           y2=y2-2;
        
        rec1=new Rectangle2D.Double(x1,y1,w1,h1);
        repaint();
       }
       if(e.getKeyCode()==KeyEvent.VK_DOWN&& ar2==true){
        h1=h1+2;   
           
        rec1=new Rectangle2D.Double(x1,y1,w1,h1);
        repaint();
       }
        if(e.getKeyCode()==KeyEvent.VK_RIGHT&& ar2==true){
        w1=w1+2;
        x2=x2+2;
        rec1=new Rectangle2D.Double(x1,y1,w1,h1);
        repaint();
       }
       if(e.getKeyCode()==KeyEvent.VK_LEFT&& ar2==true){
           x1=x1-2;
           w1=w1+2;
        rec1=new Rectangle2D.Double(x1,y1,w1,h1);
        repaint();
       }
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       if(e.getKeyCode()==KeyEvent.VK_UP && ar3==true){
           h1=h1+2;
           y1=y1-2;
        
        rec1=new Rectangle2D.Double(x1,y1,w1,h1);
        repaint();
       }
       if(e.getKeyCode()==KeyEvent.VK_DOWN&& ar3==true){
        h1=h1+2;   
        y2=y2+2;   
        rec1=new Rectangle2D.Double(x1,y1,w1,h1);
        repaint();
       }
        if(e.getKeyCode()==KeyEvent.VK_RIGHT&& ar3==true){
        w1=w1+2;    
        rec1=new Rectangle2D.Double(x1,y1,w1,h1);
        repaint();
       }
       if(e.getKeyCode()==KeyEvent.VK_LEFT&& ar3==true){
           x1=x1-2;
           w1=w1+2;
           x2=x2-2;
        rec1=new Rectangle2D.Double(x1,y1,w1,h1);
        repaint();
       }
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       if(e.getKeyCode()==KeyEvent.VK_UP && ar4==true){
           h1=h1+2;
           y1=y1-2;
        
        rec1=new Rectangle2D.Double(x1,y1,w1,h1);
        repaint();
       }
       if(e.getKeyCode()==KeyEvent.VK_DOWN&& ar4==true){
        h1=h1+2;   
        y2=y2+2;   
        rec1=new Rectangle2D.Double(x1,y1,w1,h1);
        repaint();
       }
        if(e.getKeyCode()==KeyEvent.VK_RIGHT&& ar4==true){
        w1=w1+2;
        x2=x2+2;
        rec1=new Rectangle2D.Double(x1,y1,w1,h1);
        repaint();
       }
       if(e.getKeyCode()==KeyEvent.VK_LEFT&& ar4==true){
           x1=x1-2;
           w1=w1+2;
        rec1=new Rectangle2D.Double(x1,y1,w1,h1);
        repaint();
       }
       
       
       
       
       
    }

    @Override
    public void keyReleased(KeyEvent e) {
        
    }

}
