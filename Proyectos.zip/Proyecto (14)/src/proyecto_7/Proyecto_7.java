package proyecto_7;
import java.util.Scanner;
public class Proyecto_7 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int x1,x2,y1,y2;
        Linea m=new Linea();
        Scanner scan=new Scanner(System.in);
        System.out.println("Dame x1");
        x1=scan.nextInt();
        System.out.println("Dame  y1");
        y1=scan.nextInt();
        System.out.println("Dame x2");
        x2=scan.nextInt();
        System.out.println("Dame  y2");
        y2=scan.nextInt();
        m.setX1(x1);
        m.setX2(x2);
        m.setY1(y1);
        m.setY2(y2);
        System.out.println("La pendiemte es "+ m.getPendiente());
        System.out.println("La ecuacion es "+m.toString());
        Linea m2=new Linea (2,3,7,4);
        System.out.println("La pendiente es "+ m2.getPendiente());
        m2.setX1(5);    
        m2.setY1(10);
        System.out.println("La ecuacion es "+ m2.toString());
        
    }
    
}

   class Linea {

    public double getX2() {
        return x2;
    }

    public void setX2(double x2) {
        this.x2 = x2;
    }

    public double getX1() {
        return x1;
    }

    public void setX1(double x1) {
        this.x1 = x1;
    }

    public double getY1() {
        return y1;
    }

    public void setY1(double y1) {
        this.y1 = y1;
    }

    public double getY2() {
        return y2;
    }

    public void setY2(double y2) {
        this.y2 = y2;
    }



       
     public double m,x2,x1,y1,y2;
  
    public Linea() {
      x1=getX1();
      x2=getX2();
      y1=getY1();
      y2=getY2();
    }
     public Linea(double x1,double y1,double x2,double y2){
      this.x1=x1;
      this.x2=x2;
      this.y1=y1;
      this.y2=y2;
     
     }  

      
     public double getPendiente(){
         
         
     m=(y2-y1)/(x2-x1);
     
     return m;
     } 
     
     public String toString(){
         getPendiente();
         double b;
         b=(-1*m)*x1+y1;
         if(b>0){
         return "y="+m+"x "+"+ "+b;}
         if(b<0){
              return "y="+m+"x "+" "+b;
         }
         return "y="+m+"x ";
     }
     
   } 
  